# Student Management System

Stack: HTML/CSS/JS (Fetch API) + Python Flask + SQLite.

## Run
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000  (students.db is created automatically).

## REST API
| Method | Endpoint             | Purpose                         |
|--------|----------------------|---------------------------------|
| GET    | /api/students?q=text | List / search by name or roll no |
| POST   | /api/students        | Add a student                   |
| PUT    | /api/students/<id>   | Update a student                |
| DELETE | /api/students/<id>   | Delete a student                |

Validation (server and form): required fields, unique roll no, marks 0-100, 10-digit contact.
