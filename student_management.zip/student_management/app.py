import re
import sqlite3
from flask import Flask, g, jsonify, request

app = Flask(__name__, static_folder="static", static_url_path="")
DB = "students.db"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_):
    conn = g.pop("db", None)
    if conn:
        conn.close()


def init_db():
    with sqlite3.connect(DB) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                roll_no TEXT NOT NULL UNIQUE,
                name    TEXT NOT NULL,
                class   TEXT NOT NULL,
                marks   REAL NOT NULL CHECK (marks BETWEEN 0 AND 100),
                contact TEXT NOT NULL
            )""")


def validate(data):
    """Return (clean_data, errors)."""
    errors = {}
    clean = {k: str(data.get(k, "")).strip() for k in ("roll_no", "name", "class", "contact")}
    for field, label in (("roll_no", "Roll no"), ("name", "Name"), ("class", "Class")):
        if not clean[field]:
            errors[field] = f"{label} is required."
    if not re.fullmatch(r"\d{10}", clean["contact"]):
        errors["contact"] = "Enter a 10-digit contact number."
    try:
        clean["marks"] = float(data.get("marks"))
        if not 0 <= clean["marks"] <= 100:
            raise ValueError
    except (TypeError, ValueError):
        errors["marks"] = "Marks must be a number from 0 to 100."
    return clean, errors


def row_to_dict(row):
    return dict(row)


@app.get("/")
def index():
    return app.send_static_file("index.html")


@app.get("/api/students")
def list_students():
    q = request.args.get("q", "").strip()
    sql, params = "SELECT * FROM students", []
    if q:
        sql += " WHERE name LIKE ? OR roll_no LIKE ?"
        params = [f"%{q}%", f"%{q}%"]
    rows = get_db().execute(sql + " ORDER BY roll_no", params).fetchall()
    return jsonify([row_to_dict(r) for r in rows])


@app.post("/api/students")
def add_student():
    data, errors = validate(request.get_json(silent=True) or {})
    if errors:
        return jsonify(errors=errors), 400
    try:
        db = get_db()
        cur = db.execute(
            "INSERT INTO students (roll_no, name, class, marks, contact) VALUES (?,?,?,?,?)",
            (data["roll_no"], data["name"], data["class"], data["marks"], data["contact"]),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify(errors={"roll_no": "This roll number already exists."}), 409
    return jsonify(id=cur.lastrowid), 201


@app.put("/api/students/<int:sid>")
def update_student(sid):
    data, errors = validate(request.get_json(silent=True) or {})
    if errors:
        return jsonify(errors=errors), 400
    try:
        db = get_db()
        cur = db.execute(
            "UPDATE students SET roll_no=?, name=?, class=?, marks=?, contact=? WHERE id=?",
            (data["roll_no"], data["name"], data["class"], data["marks"], data["contact"], sid),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify(errors={"roll_no": "This roll number already exists."}), 409
    if cur.rowcount == 0:
        return jsonify(error="Student not found."), 404
    return jsonify(ok=True)


@app.delete("/api/students/<int:sid>")
def delete_student(sid):
    db = get_db()
    cur = db.execute("DELETE FROM students WHERE id=?", (sid,))
    db.commit()
    if cur.rowcount == 0:
        return jsonify(error="Student not found."), 404
    return jsonify(ok=True)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
